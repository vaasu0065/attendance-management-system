import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

class Student {
    String fullName; // Store full name including first, middle, and last name
    int rollNo;
    char attendanceStatus;
}

public class AttendanceManagementSystem {

    static void enterTeacherAndSubject(String[] teacherNameSubject, Scanner scanner) {
        boolean validTeacher = false;
        boolean validSubject = false;

        while (!validTeacher) {
            System.out.print("Enter the teacher's name (characters only): ");
            String teacherInput = scanner.nextLine();

            // Check if the input contains only characters
            if (teacherInput.matches("[a-zA-Z]+")) {
                teacherNameSubject[0] = teacherInput;
                validTeacher = true;
            } else {
                System.out.println("Invalid input. Please enter only characters for the teacher's name.");
            }
        }

        while (!validSubject) {
            System.out.print("Enter the subject (characters only): ");
            String subjectInput = scanner.nextLine();

            // Check if the input contains only characters
            if (subjectInput.matches("[a-zA-Z]+")) {
                teacherNameSubject[1] = subjectInput;
                validSubject = true;
            } else {
                System.out.println("Invalid input. Please enter only characters for the subject.");
            }
        }
    }

    static int enterNumberOfStudents(Scanner scanner) {
        int numStudents = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.print("Enter the number of students in the class: ");
                numStudents = scanner.nextInt();
                validInput = true;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a numeric value for the number of students.");
                scanner.nextLine(); // Consume the invalid input
            }
        }

        scanner.nextLine(); // Consume the newline character

        return numStudents;
    }

    static void enterStudentInfo(Student[] students, Scanner scanner) {
        for (int i = 0; i < students.length; i++) {
            // Enter student name (alphabets and spaces only)
            System.out.print("Enter full name of student " + (i + 1) + ": ");
            students[i].fullName = enterAlphabeticStringInput(scanner);

            // Enter unique roll number (numeric only)
            students[i].rollNo = enterUniqueNumericInput(students, scanner, i);
        }
    }

    // Utility method to enter alphabetic string input
    static String enterAlphabeticStringInput(Scanner scanner) {
        String input = "";
        boolean validInput = false;

        while (!validInput) {
            try {
                // System.out.print("Enter full name of student: ");
                input = scanner.nextLine();
                if (input.matches("[a-zA-Z ]+") && !input.trim().isEmpty()) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter only alphabets for the student name (no numeric or empty spaces).");
                }
            } catch (Exception e) {
                System.out.println("Error reading input. Please try again.");
                scanner.nextLine(); // Consume the newline character
            }
        }

        return input;
    }

    // Utility method to enter unique numeric input for roll number
    static int enterUniqueNumericInput(Student[] students, Scanner scanner, int currentIndex) {
        int input = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.print("Enter roll number: ");
                input = scanner.nextInt();

                // Check if the roll number is unique
                if (isRollNumberUnique(students, currentIndex, input)) {
                    validInput = true;
                } else {
                    System.out.println("Roll number must be unique. Please enter a different roll number.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a numeric value for the roll number.");
                scanner.nextLine(); // Consume the invalid input
            }
        }

        scanner.nextLine(); // Consume the newline character
        return input;
    }

    // Utility method to check if the roll number is unique
    static boolean isRollNumberUnique(Student[] students, int currentIndex, int rollNumber) {
        for (int i = 0; i < currentIndex; i++) {
            if (students[i].rollNo == rollNumber) {
                return false; // Roll number already exists
            }
        }
        return true; // Roll number is unique
    }

    public static void main(String[] args) {
        int numStudents;
        String[] teacherNameSubject = new String[2];
        int continueAttendance = 1; // Initialize to 1 to start the program

        Scanner scanner = new Scanner(System.in);

        while (continueAttendance == 1) {
            // Step 1: Enter teacher name and subject
            enterTeacherAndSubject(teacherNameSubject, scanner);

            // Step 2: Enter the number of students in class
            numStudents = enterNumberOfStudents(scanner);

            Student[] students = new Student[numStudents];

            for (int i = 0; i < students.length; i++) {
                students[i] = new Student();
            }

            // Step 3: Enter student names and roll numbers
            enterStudentInfo(students, scanner);

            // Step 4: Create attendance data text file for the subject
            String filename = teacherNameSubject[1] + "_attendance.txt";

            try (FileWriter file = new FileWriter(filename)) {
                file.write("Teacher Name: " + teacherNameSubject[0] + "\n");
                file.write("Subject: " + teacherNameSubject[1] + "\n");

                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                String formattedDate = dateFormat.format(new Date());

                file.write("Attendance Date: " + formattedDate + "\n\n");

                for (Student student : students) {
                    System.out.print(student.fullName + " [" + student.rollNo + "] is ");
                    System.out.print("present (P) or absent (A) for " + teacherNameSubject[1] + "? ");
                    // scanner.nextLine(); // consume the newline character
                    student.attendanceStatus = scanner.nextLine().charAt(0);

                    file.write("Student: " + student.fullName + " [" + student.rollNo + "], Attendance: " +
                            (Character.toUpperCase(student.attendanceStatus) == 'P' ? "Present" : "Absent") + "\n");
                }

                System.out.println("\nAttendance data for " + teacherNameSubject[1] + " has been recorded in " + filename);

                // Ask the user if they want to continue or exit
                System.out.print("Do you want to continue (1 for Yes, 0 for No, 2 for Exit)? ");
                continueAttendance = scanner.nextInt();
               scanner.nextLine();

                if (continueAttendance == 2) {
                    System.out.println("Exiting the program. Thank you!");
                    break; // Exit the loop and end the program
                }

            } catch (IOException e) {
                System.out.println("Error opening/creating file: " + e.getMessage());
                e.printStackTrace();
                return;
            }
        }

        // Close the scanner after use
        scanner.close();
    }
}
